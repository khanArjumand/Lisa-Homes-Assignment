import React from 'react'
import Form from './components/forms/Form'

function App() {
  return (
    <div>
      
      <Form />
    </div>
  )
}

export default App
