import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Login from './Login';
import UserDesc from './UserDesc';


const UserEdit = (props) => {
 
 console.log(props);
 console.log(props.Editinfo.childdata.records.username);
 const [errors, setErrors] = useState({});
 const [records, setRecords] = useState({ ...props.Editinfo.childdata.records});

//setRecords(props.Editinfo.childdata);
//setRecords({...records, props.Editinfo.childdata})
  console.log("rcord data from regis " + records);
  const [dataIsCorrect, setDataIsCorrect] = useState(false);

  document.addEventListener('DOMContentLoaded', () => {

    //  const selectDrop = document.querySelector('#countries');
        const selectDrop = document.getElementById('countries');
    console.log(selectDrop.id)
    
      fetch('https://restcountries.com/v3.1/all').then(res => {
        return res.json();
      }).then(data => {
        let output = "";
        data.forEach(country => {
          output += `
          
          <option value="${country.name.common}">${country.name.common}</option>`;
          output = output + '<option selected> ' + 'Yemen' + '</option>'
        //  console.log(country.name.common);
        })
    
        selectDrop.innerHTML = output;
       // selectDrop.innerHTML.value = "Yemen";
      }).catch(err => {
        console.log(err);
      })
    
    
    });
 const handleInput = (e) => {
  const name = e.target.name;
  const value = e.target.value;
 // props.setUserRegistration({...userRegistration, [name]: value})
 setRecords({...records, [name] : value})
// console.log(records);

}
 //const { state } = this.props.location
 //console.log(this.props.location);
 
const handleselectChange = (e) => {
  const name = e.target.name;
  const value = e.target.value;
  console.log(name);
  console.log(value);
  //  const name = e.target.name;
 //   const value = e.target.value;
   // props.setUserRegistration({...userRegistration, [name]: value})
  // setRecords({...records, [name] : value} )
   // setRecords({...records, [e.target.name]: e.target.value})
   // console.log(records);
  //  props.setUserRegistration({...userRegistration, [e.target.name]: e.target.value})
 //   console.log(e.target.name);
 //   console.log(e.target.value);
  //  console.log(userRegistration);
   // setValue(e.target.value);
  };
    return (
    
  <>
  <div className="registration-form">


<form  action = "" onSubmit={(e) => { e.preventDefault();}}>
        <div className="social-icons">
            <h1>Student Details Edit </h1>
            </div>
                       
            <div className="form-group">
           
                <input type="text" className="form-control item" id="username" placeholder={props.Editinfo.childdata.records.username} value={records.username}
                 onChange={handleInput}
                name="username" id = "username"/>
                {errors.username && <p className='error'>{errors.username}</p>}
            </div>
         
            <div className="form-group">
                <input type="text" className="form-control item" id="email" placeholder={props.Editinfo.childdata.records.email} value={records.email}
                onChange={handleInput}
                name="email" />
                {errors.email && <p className='error'>{errors.email}</p>}
            </div>
            
            <div className="form-group">
                <input type="date" className="form-control item" id="birthdate" placeholder= {props.Editinfo.childdata.records.DOB} value={records.DOB} 
            onChange={handleInput}
            name="DOB"  />
            </div>

                                   
                     
            <select id="countries" name="countries" onChange={handleselectChange} > {props.cstate}</select>

            <div className="form-group">
                <button type="submit" className="btn btn-block create-account">Edit Account</button>
               
            </div>
            <div> {props.cstate} </div>
            
        </form>
  
        </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="assets/js/script.js"></script>
  </>
  )
}

export default UserEdit