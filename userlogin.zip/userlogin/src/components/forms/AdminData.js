import React from 'react';
import JsonData from './Data.json';
//import 'react-bootstrap-table/css/react-bootstrap-table.css';

const AdminData = () => {
      
    
    const DisplayData=JsonData.map(
        (info)=>{

                return(
                <tr>
                    <td>{info.id}</td>
                    <td>{info.name}</td>
                    <td>{info.Email}</td>
                    <td>{info.DOB}</td>
                    <td>{info.Country}</td>
                </tr>
            )
        }
    )
  
    return (
    
    
    
    
        <> 
    <div>AdminData</div>
    <div>
       
    <table class="table table-striped table-dark">
                <thead>
                    <tr>
                    <th>Sr.NO</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>DOB</th>
                    <th>Country</th>
                    
                    </tr>
                </thead>
                <tbody>
                 
                    
                    {DisplayData}
                    
                </tbody>
            </table>
     
             
        </div>
      </>
  )
}

export default AdminData