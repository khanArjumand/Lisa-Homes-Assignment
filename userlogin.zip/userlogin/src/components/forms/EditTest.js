import React, { useEffect, useState } from 'react'
import UserDesc from './UserDesc';

const EditTest = (props) => {

  console.log(props);
  console.log(props.Editinfo.username);
  const [errors, setErrors] = useState({});
 
  const [records, setRecords] = useState({ 
    username: "",
    email: "",
    DOB: "",
    country:"",
    password: "",
    image:"",
    Dsigned:""
   
    
});
  
  
 //setRecords(props.Editinfo.childdata);
 //setRecords({...records, props.Editinfo.childdata})
   console.log("rcord data from regis " + records);
 
    console.log("props  data " + props);

  document.addEventListener('DOMContentLoaded', () => {

    //  const selectDrop = document.querySelector('#countries');
        const selectDrop = document.getElementById('countries');
    console.log(selectDrop.id)
    
      fetch('https://restcountries.com/v3.1/all').then(res => {
        return res.json();
      }).then(data => {
        let output = "";
        data.forEach(country => {
          output += `
          
          <option value="${country.name.common}">${country.name.common}</option>`;
          output = output + '<option selected> ' + 'Yemen' + '</option>'
        //  console.log(country.name.common);
        })
    
        selectDrop.innerHTML = output;
       // selectDrop.innerHTML.value = "Yemen";
      }).catch(err => {
        console.log(err);
      })
    
    
    });
    const handleInput = (e) => {
      const name = e.target.name;
      const value = e.target.value;
     // props.setUserRegistration({...userRegistration, [name]: value})
     setRecords({...records, [name] : value})
    // console.log(records);
    
    }
  
    const handleselectChange = (e) => {
      const name = e.target.name;
      const value = e.target.value;
      console.log(name);
      console.log(value);

     // props.setUserRegistration({...userRegistration, [name]: value})
    // setRecords({...records, [name] : value} )
     // setRecords({...records, [e.target.name]: e.target.value})
     // console.log(records);
    //  props.setUserRegistration({...userRegistration, [e.target.name]: e.target.value})
   //   console.log(e.target.name);
   //   console.log(e.target.value);
    //  console.log(userRegistration);
     // setValue(e.target.value);
    };
  
    return (
    <>
    <div>EditTest</div>
    <div className="form-group">
                <input type="text" className="form-control item" id="email" placeholder={props.Editinfo.email} 
                onChange={handleInput}
                name="email" />
                {errors.email && <p className='error'>{errors.email}</p>}
            </div>
            
       
    <div>
    <select id="countries" name="countries" onChange={handleselectChange} ></select>
  
    
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="assets/js/script.js"></script>
    </>
  )
}

export default EditTest