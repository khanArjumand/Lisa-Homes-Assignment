import React from 'react'
import {  Redirect, Routes, Navigate } from 'react-router-dom';
import { LinkContainer } from 'react-router-bootstrap';
import { BrowserRouter, Route }  from 'react-router-dom';
import Home from './Home';
import Login from './Login';

const Header = () => {
  return 
  (
  <>
      <div>Header</div>
      <div className="App">
      <BrowserRouter>
        {/* Navbar */}
     
         
            <LinkContainer to="/">
              <button variant="outline-primary">Home</button>
            </LinkContainer>
            <LinkContainer to="/login">
              <button  variant="outline-primary">Login</button>
            </LinkContainer>
            <LinkContainer to="/signup">
              <button  variant="outline-primary">Signup</button>
            </LinkContainer>
     
        {/* Body */}
       
      </BrowserRouter>
      </div>
      </>
   
    
  )
}

export default Header