
const Validate = (records) => {

    let errors = {};
    if (!records.username)
    {
        errors.username = "user name is required";
        console.log(errors.username);
    }
    if (!records.email)
    {
        errors.email = "Email is required";
        console.log(errors.email);
    }
    return errors ;
   
};

export default Validate