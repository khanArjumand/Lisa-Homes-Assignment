import React from 'react'
import {  Redirect, Routes, Navigate } from 'react-router-dom';
import { LinkContainer } from 'react-router-bootstrap';
//import { BrowserRouter, Route }  from 'react-router-dom';
import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom';
import Login from './Login'
import { useState } from 'react'
import UserDesc from './UserDesc';
import UserEdit from './UserEdit';
import PropTypes from 'prop-types';
import Header from './Header';
import EditTest from './EditTest';
import AdminData from './AdminData';



const Form = () => {

 // const [cstate, setCstate] = useState({});
  document.addEventListener('DOMContentLoaded', () => {

    //  const selectDrop = document.querySelector('#countries');
   //     const selectDrop = document.getElementById('countries');
    //console.log(selectDrop.id)
    
      fetch('https://restcountries.com/v3.1/all').then(res => {
        return res.json();
      }).then(data => {
        let output = "";
        data.forEach(country => {
          output += `
          
          <option value="${country.name.common}">${country.name.common}</option>`;
        //  console.log(country.name.common);
        })
       // setCstate(output);
      //  selectDrop.innerHTML = output;

      }).catch(err => {
        console.log(err);
      })
    
    
    });

    
    const [userRegistration, setUserRegistration] = useState({
        username: "dontknoow",
        email: "kkkk@jj",
        DOB: "25-02",
        country:"UK",
        password: "3434",
        image:"",
        Dsigned:"1-3-2022"
       
        
    });
    const componentToLoad = "";
    const submitLogin = (childdata) =>
    {
     //   setUserRegistration({...userRegistration})
     setUserRegistration({childdata})
    // console.log(userRegistration);

    }

    const [formIsSubmitted,setFormIsSubmitted] = useState(false);
    console.log("formIsSubmitted in form just after init " + formIsSubmitted)

    const submitForm = () => 
    { 
         console.log( " under submitForm func and before set func setformIsSubmitted " + formIsSubmitted);
        setFormIsSubmitted(true) 
        console.log( " under submitForm func and after set func setformIsSubmitted " + formIsSubmitted);
    }
    const [IsUserClicked, setIsUserClicked] = useState(false); 
    console.log( "IsUserClicked just after initi :" +  IsUserClicked );
    const clickedLink = () => 
   { 
      setIsUserClicked(true) 
     console.log( "IsUserClicked :" +  IsUserClicked );
    }

    const whichFormToLoad = () => 
    { 
  
        
        console.log( "which form loading formIsSubmitted " + formIsSubmitted);
        if ((!formIsSubmitted) && (!IsUserClicked)) 
        {
         // componentToLoad = "<Login submitLogin= { " + submitLogin + "} submitForm={ " + submitForm + "} />" ;
         return <Login submitLogin= {   submitLogin  } submitForm={  submitForm } /> ;
        } 
        else 
        {
              if((formIsSubmitted) && (!IsUserClicked))
              {
                console.log("userRegistration value when Userdiscription loading " + {userRegistration}  )
                return  <UserDesc info = {userRegistration} clickedLink={clickedLink} submitForm={  submitForm }  />;
              }
              else
              {
                console.log("userRegistration value when UserEdit loading " + {userRegistration}  );
              
               // return  <UserEdit Editinfo = { userRegistration } /> ;
               return  <UserEdit Editinfo = { userRegistration } /> ;
              }
           
          }
          return "No condition setisfy"
        
        console.log( "which form loading  " + componentToLoad.toString());
  
        
    }
    
  return (
    <>


     
     <nav className="navbar navbar-expand-lg navbar-dark bg-warning">
  <a className="navbar-brand/"> </a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mr-auto">
      <li className="nav-item active">
        <a className="nav-link" href="/AdminData">Admin <span className="sr-only">(current)</span></a>
      </li>
      <li className="nav-item">
        
        <a className="nav-link" href="/Login">Login</a>
        
      </li>
     
    </ul>
    <form className="form-inline my-2 my-lg-0">
      <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"/>
      <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
     
<Router>
   <Routes> 
        
            
        
        <Route  path= "Login" element=  { whichFormToLoad() }   />
        <Route  path= "AdminData" element={ <AdminData /> } />
  </Routes>
  </Router>
    
     
      
      </>
  )
}

export default Form