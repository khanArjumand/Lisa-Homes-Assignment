import React, { useEffect, useState } from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Login from './Login';
import UserEdit from './UserEdit';


const UserDesc = (props) => {
//  console.log(props);
  
//  console.log(props.info);
//  console.log(props.info.childdata);
//  console.log(props.info.childdata.records);
//  console.log(props.info.childdata.records.username);
  
//  console.log(props.childdata);
  
//  console.log(props.info.username);
//  console.log(props.info.records);
  const [errors1, setErrors1] = useState({});
  
//useEffect(() => {
//    // props.submitForm(true); 
 //   console.log("error before checking error obj -"  + errors1)
 //    if (Object.keys(errors1).length == 0) {
  //      props.clickedLink(true); 
  
  //   }
 //  }, [errors1]);

  const handleuserclick = (e) => {
    console.log("Hyperlinkclicked");
   e.preventDefault()
    props.clickedLink(true); 
    props.submitForm(true); 
   console.log("props.clickedhref.IsUserClicked" + props.clickedLink.IsUserClicked)

    
}  
const handleInputs = (e) => {
  const name = e.target.name;
  const value = e.target.value;
 // props.setUserRegistration({...userRegistration, [name]: value})
// setRecords({...records, [name] : value})
// console.log(records);

}
const getAge = () => 
{
    var today = new Date();
    var birthDate = new Date(props.info.childdata.records.DOB);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
    {
        age--;
    }
    return age;
}
const getNumberOfDays = () => {
  const date1 = new Date( props.info.childdata.records.DOB);
  const date2 = new Date();

  // One day in milliseconds
  const oneDay = 1000 * 60 * 60 * 24;

  // Calculating the time difference between two dates
  const diffInTime = date2.getTime() - date1.getTime();

  // Calculating the no. of days between two dates
  const diffInDays = Math.round(diffInTime / oneDay);
  console.log("age " + diffInDays);

  return diffInDays.toString();
}
const getAge1 = () =>
{
  let tempDate = new Date();

}
 // console.log(props.info.records.username);
 // console.log(props.info.records.email);
 // console.log(props.info.records.username);
 // console.log(props.info.records.email);

 //var i = props.username;
  
 //var j = props.email;

  return (

    <>
    <div className="registration-form">
        <form >
        <div className="social-icons">
            <h3>Welcome { props.info.childdata.records.username } your data as follows  </h3>
      
         </div>    
              <div className="mb-3">
                    <label htmlFor="title" className="form-label"> <strong> <a href="/UserEdit"  onClick={handleuserclick}  > Click here </a> for data editing </strong></label>
                   
             </div>

         <div className="mb-3">
                    <label htmlFor="title" className="form-label"> <strong> User Name </strong></label>
                    <input type="text"readOnly defaultValue= { props.info.childdata.records.username } className="form-control" id="title" aria-describedby="emailHelp" />

             </div>
             <div className="mb-3">
                    <label htmlFor="title" className="form-label"> <strong>Email </strong></label>
                    <input type="text" readOnly defaultValue= { props.info.childdata.records.email } className="form-control" id="title" aria-describedby="emailHelp" />

             </div>
             <div className="mb-3">
                    <label htmlFor="title" className="form-label"> <strong> Age </strong></label>
                    <input type="text" readOnly defaultValue=  { getAge() } className="form-control" id="title" aria-describedby="emailHelp" />

             </div>
             <div className="mb-3">
                    <label htmlFor="title" className="form-label"> <strong> Country </strong></label>
                    <input type="text" readOnly defaultValue= { props.info.childdata.records.countries } className="form-control" id="title" aria-describedby="emailHelp" />

             </div>
  
            
        </form>
      
    </div>
    

    
    


    </>
    
  )
}

export default UserDesc