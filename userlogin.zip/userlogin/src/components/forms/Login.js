import React, { useEffect, useState } from 'react'
import UserDesc from './UserDesc';
import Validate from './Validate';
import { createHashHistory } from 'history';


 const Login = (props) => {
  
 //  const [cstate, setCstate] = useState({});
    document.addEventListener('DOMContentLoaded', () => {

      //  const selectDrop = document.querySelector('#countries');
          const selectDrop = document.getElementById('countries');
      console.log(selectDrop.id)
      
        fetch('https://restcountries.com/v3.1/all').then(res => {
          return res.json();
        }).then(data => {
          let output = "";
          data.forEach(country => {
            output += `
            
            <option value="${country.name.common}">${country.name.common}</option>`;
          //  console.log(country.name.common);
          })
        //  setCstate(output);
          selectDrop.innerHTML = output;

        }).catch(err => {
          console.log(err);
        })
      
      
      });
    

    const [errors, setErrors] = useState({});
    const [records, setRecords] = useState({ 
   
      username: "",
      email: "",
      DOB: "",
      countries:"",
      password: "",
      image:"",
      Dsigned:""
    });
     const [dataIsCorrect, setDataIsCorrect] = useState(false);
 
  
     useEffect(() => {

      if (Object.keys(errors).length == 0 && dataIsCorrect) {
      
        props.submitLogin({ records })
        props.submitForm(true); 
      }    
    }, [errors]);

   // useEffect(() => {
     // props.submitForm(true); 
    // console.log("error before checking error obj -"  + errors)
    //  if (Object.keys(errors).length == 0 && dataIsCorrect) {
    //    props.submitForm(true); 
   //   }
   // }, [errors]);
    
   
    
    const handleInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
       // props.setUserRegistration({...userRegistration, [name]: value})
       setRecords({...records, [name] : value})
      // console.log(records);

    }
    const handleSubmit = (e) => {
        e.preventDefault()

       // setErrors(Validate(userRegistration))
        setErrors(Validate(records))
        console.log(new Date().toLocaleString() + '')
       // const newRecord = {...userRegistration, id:new Date().toLocaleString() + '', Dsigned:new Date().toLocaleString() + ''}
        const newRecord = {...records, id:new Date().toLocaleString() + '', Dsigned:new Date().toLocaleString() + ''}
        console.log(newRecord)
        setRecords({...records, newRecord})
        console.log(records)
        console.log(records.username)
        console.log("cheking error before setting submitform flage " + Object.keys(errors).length )
        console.log("cheking error before setting submitform flage " + errors )
       // if (Object.keys(errors).length == 0 ) {
         // console.log("cheking error before setting submitform flage " + Object.keys(errors).length )
          //props.submitLogin({ records })
          //props.submitForm(true); 
        //  } 
      //  if(records.username != "")
      //  {
     //   props.submitLogin({ records })
      //  }
      // history.push('/UserDesc')
     //   props.submitForm(true); 
       
      //  props.submitLogin({username:"bob", email:"bob@gma",DOB:"56", country:"US", password:"123",Dsigned:"1-3-2022" })
      //  console.log(userRegistration);
       // UserDesc(userRegistration) ;                 
       // setUserRegistration({username:"", email:"",DOB:"", country:"", password:"",Dsigned:"" })
       
      //setFormIsSubmitted(true);
      setDataIsCorrect(true);

    }  

      
    const getDateTime = () => {
        let tempDate = new Date();
        let date = tempDate.getFullYear() + '-' + (tempDate.getMonth()+1) + '-' + tempDate.getDate() +' '+ tempDate.getHours()+':'+ tempDate.getMinutes()+':'+ tempDate.getSeconds(); 
        const currDate = "Current Date= "+date;
        this.setState({ reportStartDate: currDate})
        return currDate
      }
      const handleselectChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
       // props.setUserRegistration({...userRegistration, [name]: value})
       setRecords({...records, [name] : value} )
       // setRecords({...records, [e.target.name]: e.target.value})
       // console.log(records);
      //  props.setUserRegistration({...userRegistration, [e.target.name]: e.target.value})
     //   console.log(e.target.name);
     //   console.log(e.target.value);
      //  console.log(userRegistration);
       // setValue(e.target.value);
      };
  return (
 <>
 
 
   <div className="registration-form">
        <form  action = "" onSubmit={handleSubmit}>
        <div className="social-icons">
            <h1>Student Registration </h1>
            </div>
                       
            <div className="form-group">
           
                <input type="text" className="form-control item" id="username" placeholder="Username" value={records.username}
                 onChange={handleInput}
                name="username" />
                {errors.username && <p className='error'>{errors.username}</p>}
            </div>
         
            <div className="form-group">
                <input type="text" className="form-control item" id="email" placeholder="Email" value={records.email}
                onChange={handleInput}
                name="email" />
                {errors.email && <p className='error'>{errors.email}</p>}
            </div>
            <div className="form-group">
                <input type="date" className="form-control item" id="birthdate"  value={records.DOB}
            onChange={handleInput}
            name="DOB" />
            </div>
                            
            <select id="countries" name="countries" onChange={handleselectChange}></select>

            <div className="form-group">
                <button type="submit" className="btn btn-block create-account">Create Account</button>
            </div>
            
        </form>
      
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="assets/js/script.js"></script>

    </>
  )
}

export default Login